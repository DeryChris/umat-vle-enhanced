<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_umat_ai';
$plugin->version   = 2026051900;
$plugin->requires  = 2023100900;
$plugin->maturity  = MATURITY_BETA;
$plugin->release   = '1.3.0';
